#include <stdio.h>
#include <string.h>
#include "decode.h"
#include "common.h"

/*----------------------------------------------------------
Function Name  : open_img_files
Description    : Opens the stego image file in read mode
Input          : decInfo structure
Output         : success / failure
-----------------------------------------------------------*/
Status open_img_files(Decodeinfo *decInfo)
{
    /* Open stego image file */
    decInfo->img_fptr = fopen(decInfo->img_name, "r");

    /* Error handling if file is not opened */
    if (decInfo->img_fptr == NULL)
    {
        perror("fopen");
        printf("ERROR : Unable to open file %s\n", decInfo->img_name);
        return failure;
    }

    return success;
}

/*----------------------------------------------------------
Function Name  : validate_decode_args
Description    : Validates command line arguments for decoding
Input          : argv[], decInfo structure
Output         : success / failure
-----------------------------------------------------------*/
Status validate_decode_args(char *argv[], Decodeinfo *decInfo)
{
    /* Check whether the given file is bmp format */
    if (strstr(argv[2], ".bmp") != NULL)
    {
        /* Store image file name */
        decInfo->img_name = argv[2];
    }
    else
    {
        printf("ERROR : Invalid .bmp file\n");
        return failure;
    }

    /* Check whether output file name is given */
    if (argv[3] != NULL)
    {
        /* Remove extension if user gives extension */
        strtok(argv[3], ".");

        /* Store output file name */
        strcpy(decInfo->scrt_fname, argv[3]);
    }
    else
    {
        /* Default output file name */
        strcpy(decInfo->scrt_fname, "decoded");

        printf("INFO  : Output file not mentioned, default name is added\n");
        printf("\n");
    }

    return success;
}

/*----------------------------------------------------------
Function Name  : decode_1byte_to_lsb
Description    : Decodes one character from image LSB bits
Input          : data, decInfo structure
Output         : success
-----------------------------------------------------------*/
Status decode_1byte_to_lsb(char *data, Decodeinfo *decInfo)
{
    char image_buffer[8];

    /* Read 8 bytes from image */
    fread(image_buffer, 1, 8, decInfo->img_fptr);

    *data = 0;

    /* Extract LSB bits and form one character */
    for (int i = 0; i < 8; i++)
    {
        int bit = image_buffer[i] & 1;

        *data = (*data << 1) | bit;
    }

    return success;
}

/*----------------------------------------------------------
Function Name  : decode_4byte_to_lsb
Description    : Decodes 32-bit integer from image LSB bits
Input          : decInfo structure
Output         : Decoded integer value
-----------------------------------------------------------*/
Status decode_4byte_to_lsb(Decodeinfo *decInfo)
{
    char image_buffer[32];
    int size = 0;

    /* Read 32 bytes from image */
    fread(image_buffer, 1, 32, decInfo->img_fptr);

    /* Extract LSB bits and form integer value */
    for (int i = 0; i < 32; i++)
    {
        int bit = image_buffer[i] & 1;

        size = (size << 1) | bit;
    }

    return size;
}

/*----------------------------------------------------------
Function Name  : decode_magic_string
Description    : Decodes and verifies magic string
Input          : decInfo structure
Output         : success / failure
-----------------------------------------------------------*/
Status decode_magic_string(Decodeinfo *decInfo)
{
    char magic[3];

    /* Skip BMP header */
    fseek(decInfo->img_fptr, 54, SEEK_SET);

    /* Decode two characters of magic string */
    for (int i = 0; i < 2; i++)
    {
        decode_1byte_to_lsb(&magic[i], decInfo);
    }

    magic[2] = '\0';

    /* Compare decoded string with original magic string */
    if (strcmp(magic, MAGIC_STRING) == 0)
    {
        printf("INFO  : Magic string decoded successfully\n");
        printf("\n");

        return success;
    }

    printf("ERROR : Magic string mismatch\n");

    return failure;
}

/*----------------------------------------------------------
Function Name  : decode_secret_file_extn
Description    : Decodes secret file extension
Input          : decInfo structure
Output         : success / failure
-----------------------------------------------------------*/
Status decode_secret_file_extn(Decodeinfo *decInfo)
{
    /* Decode extension size */
    int extn_size = decode_4byte_to_lsb(decInfo);

    /* Decode extension characters */
    for (int i = 0; i < extn_size; i++)
    {
        decode_1byte_to_lsb(&decInfo->scrt_ext[i], decInfo);
    }

    /* Add null terminator */
    decInfo->scrt_ext[extn_size] = '\0';

    printf("INFO  : Decoded file extension is %s\n", decInfo->scrt_ext);

    /* Append extension to output file name */
    strcat(decInfo->scrt_fname, decInfo->scrt_ext);

    return success;
}

/*----------------------------------------------------------
Function Name  : open_secrete_file
Description    : Opens decoded output file in write mode
Input          : decInfo structure
Output         : success / failure
-----------------------------------------------------------*/
Status open_secrete_file(Decodeinfo *decInfo)
{
    /* Open output file */
    decInfo->scrt_fptr = fopen(decInfo->scrt_fname, "w");

    /* Error handling */
    if (decInfo->scrt_fptr == NULL)
    {
        perror("fopen");

        printf("ERROR : Unable to create file %s\n",
               decInfo->scrt_fname);

        return failure;
    }

    return success;
}

/*----------------------------------------------------------
Function Name  : decode_secret_file_data
Description    : Decodes secret file content from image
Input          : decInfo structure
Output         : success / failure
-----------------------------------------------------------*/
Status decode_secret_file_data(Decodeinfo *decInfo)
{
    /* Decode secret file size */
    int file_size = decode_4byte_to_lsb(decInfo);

    printf("INFO  : Secret file size is %d bytes\n", file_size);

    /* Decode each character from image */
    for (int i = 0; i < file_size; i++)
    {
        char ch;

        /* Decode one byte */
        decode_1byte_to_lsb(&ch, decInfo);

        /* Write decoded character into output file */
        fwrite(&ch, 1, 1, decInfo->scrt_fptr);
    }

    return success;
}

/*----------------------------------------------------------
Function Name  : do_decoding
Description    : Performs complete decoding process
Input          : argv[], decInfo structure
Output         : success / failure
-----------------------------------------------------------*/
Status do_decoding(char *argv[], Decodeinfo *decInfo)
{
    /* Open image file */
    if (open_img_files(decInfo) == failure)
    {
        printf("ERROR : Files are not opened\n");

        return failure;
    }
    else
    {
        printf("INFO  : Files opened successfully\n");
        printf("\n");
    }

    /* Decode magic string */
    if (decode_magic_string(decInfo) == failure)
    {
        return failure;
    }

    /* Decode secret file extension */
    if (decode_secret_file_extn(decInfo) == failure)
    {
        printf("ERROR : Failed to decode extension\n");

        return failure;
    }
    else
    {
        printf("INFO  : File extension decoded successfully\n");
        printf("\n");
    }

    /* Open decoded output file */
    if (open_secrete_file(decInfo) == failure)
    {
        return failure;
    }
    else
    {
        printf("INFO  : Output file created successfully\n");
        printf("\n");
    }

    /* Decode secret file data */
    if (decode_secret_file_data(decInfo) == failure)
    {
        printf("ERROR : Failed to decode file data\n");

        return failure;
    }
    else
    {
        printf("INFO  : Secret file data decoded successfully\n");
        printf("\n");
    }

    /* Close opened files */
    fclose(decInfo->img_fptr);
    fclose(decInfo->scrt_fptr);

    return success;
}