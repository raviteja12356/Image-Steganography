#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "common.h"

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
unsigned int get_image_size_for_bmp(FILE *fptr_image)
{
    unsigned int width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}
/*
*secreate file size
*By using ftell we get secreate file size
**/
unsigned int get_file_size(FILE *fptr)
{
    fseek(fptr,0,SEEK_END);
    unsigned int size=ftell(fptr);
    return size;

}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: success or failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    encInfo->src_image_fptr = fopen(encInfo->src_image_fname, "r");

    if (encInfo->src_image_fptr == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return failure;
    }

    encInfo->secret_fptr = fopen(encInfo->secret_fname, "r");

    if (encInfo->secret_fptr == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return failure;
    }

    encInfo->output_image_fptr = fopen(encInfo->output_image_fname, "w");

    if (encInfo->output_image_fptr == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->output_image_fname);

    	return failure;
    }

    return success;
}

Opr_type check_operation(char *option)
{
    if(strcmp(option,"-e")==0)// if command -e means starts encoding 
    {
        return encode;
    }
    else if(strcmp(option,"-d")==0)// if command -d means decoding
    {
        return decode;
    }

    return unsupported; // if both or false means it is invalid command
}

Status validate_encode_args(char *argv[], EncodeInfo *encInfo)
{   
    char *retbmp=strstr(argv[2],".bmp");
    int ret1=strcmp(retbmp,".bmp");
    if(ret1!=0) // checking the image file extention .bmp  present means it return address else it return 
    {
        printf("ERROR: Source img file is not .bmp image\n"); // if not found .bmp it strstr NULL   means not found
        return failure; // failure not found the .bmp file not present 
    }
    // if .bmp image file present means storing to the structures
    encInfo->src_image_fname = argv[2];
    printf("Src file is .bmp\n");

    // secreate file extiction checking
    char *ret=strstr(argv[3],".");
    if(ret==NULL)
    {
        printf("ERROR: Please pass the valid file. (ex: .txt, .c, .sh)\n");
        return failure;
    }
    if(strcmp(ret,".txt")!=0 && strcmp(ret,".c")!=0 && strcmp(ret,".cpp")!=0)
    {
        return failure;

    }
    
    else
    {
    strcpy(encInfo->secret_extn,ret);// copying the secreate file extintion

    
    encInfo->secret_extn_size=strlen(ret);// secreate file size
    encInfo->secret_fname = argv[3];// secrete file name string to structure
    }
    // output file is menstion in the arguments or not checking if not default name giving
    if(argv[4]!=NULL)
    {
        if(strstr(argv[4],".bmp")==NULL)// Here checking the user bmp file name
        {
            printf("Error: Source file must be a .bmp image\n");
            return failure;
        }
        encInfo->output_image_fname= argv[4];
    }
    else
    {
        printf("INFO  :  Output file not mentioned, default file name is added\n");
        printf("\n");
        encInfo->output_image_fname="Output.bmp";// if user not send default output name 
    }
    
    return success;
}

Status do_encoding(char *argv[],EncodeInfo *encInfo)
{
    if(open_files(encInfo)==failure)// opening the all files 
    {
       printf("ERROR: opening the file has failed\n");
       return failure;// if failure return to main function
    }
    
       printf("INFO  :  Files are opened successfully\n");
       printf("\n");
    /*
    * checking the secret file size and input image file size
    * if the secrete file size is greater then image file size 
    * it will failed bacause it is more than the input image file 
    */
    if(check_capacity(encInfo)==failure)//checking the capacity of the of the secret message and image size
    {
        printf("ERROR: checking file  capacity is failed\n");
        return failure;
    }
     printf("INFO  :  Checking file capacity successfully completed\n");
     printf("\n");

    if(copy_bmp_header(encInfo)==failure)// first 54 bytes of data we are copying to the output file
    {
       printf("ERROR: header is not copied correctly\n");
        return failure;
    }
     printf("INFO  :  Copy bmp header is successful\n");
     printf("\n");
    
    if(encode_magic_string(MAGIC_STRING,encInfo)==failure)// checking the magic string is present or not 
    {
         printf("ERROR: Magic string is not encoded correctly\n");
        return failure;// if the magic string is not present encoding will be failed with the messsage
    }
     printf("INFO  :  Magic string encoded successfully\n");
     printf("\n");

    if(encode_secret_file_extn(encInfo)==failure)// secrete file extetion encoding
    {
         printf("ERROR: secret file extention is not  encoded correctly\n");
         return failure;// if fails return with the message
    } 
      printf("INFO  :  Secret file extenstion  Encoded successfully\n");
      printf("\n"); 
   
    if(encode_secret_file_data(encInfo)==failure)// encoding the secreate file
    {
         printf("ERROR: secret file data  is not  encoded correctly\n");
        return failure;// if secrete file encoding fails it will return to previos function
    }
    printf("INFO  :  Secret file data  Encoded successfully\n");
    printf("\n");

    //After encoding all the informaton we have to copy the remaining data to get the image looks
    if(copy_remaining_img_data(encInfo)==failure)
    {
        printf("ERROR: copying the remening  data is failed\n");
        return failure;
    }
     printf("INFO  :  Remaining data successfully copied\n");
     printf("\n");
    /*
    After copying the all data we are closeing the files 
    -> Beacause Memory/resource leak
    ->File corruption possibility*/
    fclose(encInfo->src_image_fptr);
    fclose(encInfo->secret_fptr);
    fclose(encInfo->output_image_fptr);
   
    return success;
}
// checking the capacity

/*
-> Here we checking the capacity of the secrete file
-> The Orginal image file size calculating
-> checking magic string 
*/
Status check_capacity(EncodeInfo *encInfo)
{
    printf("Checking for %s file size %s file size\n",encInfo->secret_fname,encInfo->src_image_fname);
    printf("\n%s File size : \n",encInfo->src_image_fname);
    unsigned int img_capacity=get_image_size_for_bmp(encInfo->src_image_fptr);//  getting the image size from the file pointer
    
    encInfo->secret_file_size=get_file_size(encInfo->secret_fptr);// Reading secrete file size
    if(encInfo->secret_file_size<=0)// incase secrete file is empty there is no information means it will return EOF is -1
    {
        printf("%s file is empty\n",encInfo->secret_fname);
        return failure;
    }
    printf("Done Not Empty\n\n");
    int Encoding_things=(strlen(MAGIC_STRING)* 8 + 4 * 8 + encInfo->secret_file_size * 8);// magic string lenght and extesion file size and secrete file size these are all multiple with 8 beacause 1 byte = 8bits 
    // we need to encode every byte of last bit 
    // checking the capacity of the file
    printf("Checking for %s Capacity to handle %s\n",encInfo->src_image_fname,encInfo->secret_fname);
    if(img_capacity>Encoding_things)
    {
        return success;
    }
    else
    {
        printf("%s file is Greater Then the %s file size\n",encInfo->secret_fname,encInfo->src_image_fname);
        return failure;
    }
}

Status copy_bmp_header(EncodeInfo *encInfo)
{
    rewind(encInfo->src_image_fptr);
    char header[60];
    if( fread(&header,sizeof(char),54,encInfo->src_image_fptr)==1)
    {
        return failure;
    }
    if (fwrite(&header,sizeof(char),54,encInfo->output_image_fptr)==1)
    {
        return failure;
    }
    return success;
}

Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    int str_len=strlen(magic_string),i;// getting size of the magic string 
    char buffer[9];
    
    for(i=0; i<str_len; i++)// magic string times we are running the loop
    {
        fread(&buffer,sizeof(char),8,encInfo->src_image_fptr);//reading the 8bytes from the source file
        encode_1byte_to_lsb(magic_string[i],buffer);// encoding the duping the magic string
        fwrite(&buffer,sizeof(char),8,encInfo->output_image_fptr);// writing into the output file
    }
    return success;// after completing return succes
}

Status encode_1byte_to_lsb(char data,char *buffer_8)
{
    int i;
    for(i=7; i>=0; i--)
    {
        buffer_8[7-i]=(buffer_8[7-i]&~(1))|(data>>i)&1;
    } 
}

Status encode_4byte_to_lsb(int data, char *buffer_32)
{
    int i;
    for(i=31; i>=0; i--)
    {
        buffer_32[31-i]=(buffer_32[31-i]&~(1))|(data>>i)&1;
    }
}

Status encode_secret_file_extn(EncodeInfo *encInfo)
{
    char buffer[33];
    int i;
    /*
    *32 bytes reading because secrete file ext_size 4byte 4*8bits=32 bits 
    *so in souce file we need 32 bytes to encode or read
    *32 bytes after reading write into destination file
    */
    printf("Encoding %s File size\n",encInfo->secret_fname);
    fread(&buffer,sizeof(char),32,encInfo->src_image_fptr);// reading the 32 bytes from the source file 
    encode_4byte_to_lsb(encInfo->secret_extn_size,buffer);//calling the function to encode secrete entension size
    fwrite(&buffer,sizeof(char),32,encInfo->output_image_fptr);// encodedd data writing into the output file
    printf("Done\n");
    
    char buffer1[8];
    
    printf("Encoding %s File Data\n",encInfo->secret_fname);
    for(i=0; i<encInfo->secret_extn_size; i++)// secrete extnsion size we are running the loop
    {
        fread(&buffer1,sizeof(char),8,encInfo->src_image_fptr);//reading 8 bytes from the souurce file
        encode_1byte_to_lsb(encInfo->secret_extn[i],buffer1);// calling the function to encode the secrete file ext
        fwrite(&buffer1,sizeof(char),8,encInfo->output_image_fptr);// encodedd data writing into the output file
    }
    
    return success;
}

Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char buffer[32],buffer1[8],ch;
    int i;
    fread(&buffer,sizeof(char),32,encInfo->src_image_fptr);// Reading the 32 bytes from the source file
    encode_4byte_to_lsb(encInfo->secret_file_size,buffer);//  Calling the function to encode the secrete file size
    fwrite(&buffer,sizeof(char),32,encInfo->output_image_fptr);//Encodedd data writing into the output file

    
    rewind(encInfo->secret_fptr);//Secreate pointer will point to first byte of the file 
    
    for(i=0; i<encInfo->secret_file_size; i++)// running the file secreate file size loop runs
    {
        fread(&ch,sizeof(char),1,encInfo->secret_fptr);// Reading the secreat data from the secrete file
        fread(&buffer1,sizeof(char),8,encInfo->src_image_fptr);//Reading the 8 byes froms the source file
        encode_1byte_to_lsb(ch,buffer1);// Calling the function to encode the secreate data
        fwrite(&buffer1,sizeof(char),8,encInfo->output_image_fptr);// Encodded secreate data writing to the output image file
    }
    return success;
}

Status copy_remaining_img_data(EncodeInfo * encInfo)
{
    char ch;
    while(fread(&ch,sizeof(char),1,encInfo->src_image_fptr)>0)
    {
        fwrite(&ch,sizeof(char),1,encInfo->output_image_fptr);
    }

    return success;
}