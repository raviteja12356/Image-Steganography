#include<stdio.h>
#include<string.h>
#include"common.h"
#ifndef DECODE_H
#define DECODE_H
typedef struct Decodeinfo
{
    FILE *img_fptr;
    char *img_name;


    FILE *scrt_fptr;
    char scrt_fname[20];
    char scrt_ext[10];

}Decodeinfo;

/* Read and validate Decode args from argv */
Status validate_decode_args(char *argv[],Decodeinfo *decInfo);

/* Perform the Decoding */
Status do_decoding(char *argv[], Decodeinfo *decInfo);

/* Open the file read mode */
Status open_img_files(Decodeinfo *decInfo);

/* Stored Magic String Decoding*/
Status decode_magic_string(Decodeinfo *decInfo);

/* decode 1 byte into LSB of image data array */
Status decode_1byte_to_lsb(char *data, Decodeinfo *decInfo);

/* decode 4byte(int) into LSB of image data array */
Status decode_4byte_to_lsb(Decodeinfo *decInfo);

/* decode secret file extenstion */
Status decode_secret_file_extn(Decodeinfo *decInfo);
/*Opening the secrete file in write mode*/
Status open_secrete_file(Decodeinfo *decInfo);

/* Decode secret file data*/
Status decode_secret_file_data(Decodeinfo *decInfo);

#endif