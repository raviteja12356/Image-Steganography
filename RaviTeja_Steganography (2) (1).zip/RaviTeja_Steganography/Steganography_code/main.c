/*
    NAME : KOCHERLA RAVITEJA
    DATE : 23/05/2026
    Description:-
                    This project implements Image Steganography using the LSB
                    technique in C to hide secret data inside a BMP image without affecting
                    image quality. It supports encoding and decoding of secret text using 
                    bitwise operations, file handling, and command-line arguments.
                    A magic string is used to verify hidden data, making the project a simple 
                    and effective example of secure data hiding and low-level programming.

*/
#include <stdio.h>
#include "encode.h"
#include "decode.h"

int main(int argc, char *argv[])
{
    EncodeInfo encodeInfo;
    Decodeinfo decInfo;
    if( argc == 1 )
    {
	// print -> Error + usage msg
    printf("Encoding: ./lsb_stego -e <.bmp file> <.txt file> [output file]\nDecoding: ./lsb_stego -e <.bmp file> [output file]\n");
	return 0;
    }

    int opr = check_operation(argv[1]);

    if( opr == encode )
    {
	  if( argc < 4 || argc > 5 )
	  {
	    // print -> Error + usage msg
        printf("ERROR: Encoding requires at least 4 arguments.\n");
        printf("\n");
        printf("INFO  :  Please enter like this %s -e <source_image> <secret_file> <stego_image>\n", argv[0]);
	    return 0;
	  }
      if(validate_encode_args(argv,&encodeInfo)==success)
      {
        printf("INFO  :  Read and validate is  successully completed for Encoding\n");
        printf("\n");

        if(do_encoding(argv,&encodeInfo)==success)
        {
           printf("..........................................\n");
           printf("INFO  :  Encoding Completed successfully\n");
           printf("..........................................\n");
        }
        else
        {
            printf("Encoding has failed\n");
            return 0;
        }
      } 
    }
    else if( opr == decode )
    {
	   if( argc < 3 || argc > 4 )	
	   {
	     // print -> Error + usage msg
         printf("ERROR: decoding requires at least 3 arguments.\n");
         printf("\n");
         printf("INFO  :  Please enter like this %s -d <stego_image> <optional>\n", argv[0]);
	     return 0;
	   }
       printf("INFO  :  Selected Decoding , Decoding Started\n");
       printf("\n");
       if(validate_decode_args(argv,&decInfo)==success)
       {
           printf("INFO  :  Read and validate is  successully completed for Decoding\n");
           printf("\n");
           if(do_decoding(argv,&decInfo)== success)
           {
               printf("..........................................\n");
               printf("INFO  :  Decoding Completed successfully\n");
               printf("..........................................\n");
    
           }
           else
           {
              printf("decoding is not done correctly\n");
           }
       }
       
    }
    else
    {
	  // Print -> Error + usage msg
      printf("encoding and decoding is not correctly done\n") ; 
      printf("Encoding: ./lsb_stego -e <.bmp file> <.txt file> [output file]\nDecoding: ./lsb_stego -e <.bmp file> [output file]\n");
    }
    return 0;
}
